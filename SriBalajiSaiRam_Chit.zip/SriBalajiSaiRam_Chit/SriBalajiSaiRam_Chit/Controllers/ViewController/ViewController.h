//
//  ViewController.h
//  SriBalajiSaiRam_Chit
//
//  Created by kireeti on 09/02/19.
//  Copyright © 2019 KireetiSoftSolutions. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Constants.h"

@interface ViewController : UIViewController

-(float)viewWidth;
-(float)viewHeight;
-(void)setcolourofbutton:(UIButton *)button stringtitle:(NSString *)titlebtn;
@end
