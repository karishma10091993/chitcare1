//
//  Constants.h
//  SriBalajiSaiRam_Chit
//
//  Created by kireeti on 09/02/19.
//  Copyright © 2019 KireetiSoftSolutions. All rights reserved.


#import <UIKit/UIKit.h>

#pragma mark--- Color keys ---


#define KStringCompanyName @"SriBalaji SaiRam Chit Fund Pvt. Ltd."
#define kImageLogo @"sbsr small.png"
#define APPREDCOLOR [UIColor colorWithRed:(174.0/255.0) green:(0.0/255.0) blue:(0.0/255.0) alpha:1]
#pragma mark -------- Array Strings ------------

@interface Constants : UIViewController

@end
